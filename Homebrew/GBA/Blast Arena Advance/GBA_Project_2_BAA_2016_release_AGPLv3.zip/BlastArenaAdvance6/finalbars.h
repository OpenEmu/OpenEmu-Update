//
// finalbars declarations
//

#ifndef __FINALBARS__
#define __FINALBARS__

extern const int finalbarsWidth;
extern const int finalbarsHeight;
extern const int finalbarsLen;
extern const unsigned int finalbarsData[];
extern const int finalbarsPalLen;
extern const unsigned int finalbarsPal[];

#endif // __FINALBARS__

