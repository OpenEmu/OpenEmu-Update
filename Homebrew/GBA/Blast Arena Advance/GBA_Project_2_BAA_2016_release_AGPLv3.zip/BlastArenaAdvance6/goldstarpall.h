//
// goldstarpall declarations
//

#ifndef __GOLDSTARPALL__
#define __GOLDSTARPALL__

extern const unsigned int goldstarpallPal[];

#endif // __GOLDSTARPALL__

