//======================================================================
//	goldstarpall, 64x64@4, tiles. (mode 0,1,2; obj)
//	(Creation date: 2005-03-22, 18:54:25)
//
//	Exported by Cearn's Usenti v1.6.1
//	(comments, kudos, flames to "daytshen@hotmail.com")
//======================================================================

#include "goldstarpall.h"

const unsigned int goldstarpallPal[4]=
{
	0x00c60000, 0x0252018c, 0x03ff0318, 0x57ff2bff, 
};

