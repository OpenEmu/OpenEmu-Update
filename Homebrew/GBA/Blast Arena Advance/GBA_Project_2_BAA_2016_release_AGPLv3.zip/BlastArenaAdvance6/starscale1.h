// =====================================================================
//
//	Exported by Cearn's excellut v1.0
//	(comments, kudos, flames to daytshen@hotmail.com)
//
// =====================================================================

#ifndef STARSCALE1_H
#define STARSCALE1_H

// === LUT DECLARATIONS ===
extern const signed short RECIPSTARSCALE[175];

#endif	// STARSCALE1_H
