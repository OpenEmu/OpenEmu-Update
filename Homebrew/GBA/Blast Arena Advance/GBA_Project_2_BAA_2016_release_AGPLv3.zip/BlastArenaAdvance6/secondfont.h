//
// secondfont declarations
//

#ifndef __SECONDFONT__
#define __SECONDFONT__

extern const int secondfontWidth;
extern const int secondfontHeight;
extern const int secondfontLen;
extern const unsigned int secondfontData[];
extern const int secondfontPalLen;
extern const unsigned int secondfontPal[];

#endif // __SECONDFONT__

