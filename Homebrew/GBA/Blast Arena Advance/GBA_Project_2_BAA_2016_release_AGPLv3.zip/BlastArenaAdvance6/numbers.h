//
// numbers declarations
//

#ifndef __NUMBERS__
#define __NUMBERS__

extern const int numbersWidth;
extern const int numbersHeight;
extern const int numbersLen;
extern const unsigned int numbersData[];
extern const int numbersPalLen;
extern const unsigned int numbersPal[];

#endif // __NUMBERS__

