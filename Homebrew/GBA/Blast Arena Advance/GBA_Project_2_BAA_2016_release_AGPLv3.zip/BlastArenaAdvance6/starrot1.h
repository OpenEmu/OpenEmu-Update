// =====================================================================
//
//	Exported by Cearn's excellut v1.0
//	(comments, kudos, flames to daytshen@hotmail.com)
//
// =====================================================================

#ifndef STARROT1_H
#define STARROT1_H

// === LUT DECLARATIONS ===
extern const signed short STARROT[175];

#endif	// STARROT1_H
