//======================================================================
//	spritelight, 40x8@4, tiles. (mode 0,1,2; obj)
//	(Creation date: 2005-05-30, 22:36:51)
//
//	Exported by Cearn's Usenti v1.6.1
//	(comments, kudos, flames to "daytshen@hotmail.com")
//======================================================================

#include "spritelight.h"

const int spritelightWidth= 40;
const int spritelightHeight= 8;
const int spritelightLen= 160;

const unsigned int spritelightData[40]=
{
	0x00000000, 0x00000000, 0x00088800, 0x00678800, 0x00577800, 0x00656000, 0x00000000, 0x00000000, 
	0x00000000, 0x00000000, 0x00044400, 0x00234400, 0x00133400, 0x00212000, 0x00000000, 0x00000000, 
	0x00000000, 0x00793970, 0x00934490, 0x00344430, 0x00934390, 0x00793970, 0x00000000, 0x00000000, 
	0x00000000, 0x00b939b0, 0x00934490, 0x00344430, 0x00934390, 0x00b939b0, 0x00000000, 0x00000000, 
	0x00b999b0, 0x0b93449b, 0x0934aa49, 0x0934aa49, 0x09344439, 0x0b93339b, 0x00b999b0, 0x00000000, 
};

const int spritelightPalLen= 64;
const unsigned int spritelightPal[16]=
{
	0x4d473000, 0x001f4905, 0x3ca3291f, 0x180f3c82, 0x0019348f, 0x7c1f7fff, 0x7c1f7c1f, 0x7c1f7c1f, 
	0x4d473000, 0x23bf4905, 0x3ca303ff, 0x10cf3c82, 0x0339012f, 0x01d07fff, 0x7c1f7c1f, 0x7c1f7c1f, 
};

