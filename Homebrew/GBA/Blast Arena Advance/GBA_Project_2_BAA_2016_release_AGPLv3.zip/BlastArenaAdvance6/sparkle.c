//======================================================================
//	sparkle, 8x8@4, tiles. (mode 0,1,2; obj)
//	(Creation date: 2005-03-20, 22:25:45)
//
//	Exported by Cearn's Usenti v1.6.1
//	(comments, kudos, flames to "daytshen@hotmail.com")
//======================================================================

#include "sparkle.h"

const int sparkleWidth= 8;
const int sparkleHeight= 8;
const int sparkleLen= 32;

const unsigned int sparkleData[8]=
{
	0x00003000, 0x00004000, 0x00034300, 0x03442443, 0x00034300, 0x00004000, 0x00003000, 0x00000000, 
};

