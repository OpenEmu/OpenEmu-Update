//
// grey declarations
//

#ifndef __GREY__
#define __GREY__

extern const unsigned int greyPal[];

#endif // __GREY__

