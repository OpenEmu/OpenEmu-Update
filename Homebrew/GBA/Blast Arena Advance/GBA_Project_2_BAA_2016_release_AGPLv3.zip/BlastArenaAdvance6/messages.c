#include "messages.h"

const char copyright2[] = "Unauthorized distribution is just fucking not on. Alright?";
const char copyright[] = "Blast Arena GBA is copyright Mathew Carr (aka MrD) 2005, based on Blast Arena by Edward Biddulph (aka carpets).";

