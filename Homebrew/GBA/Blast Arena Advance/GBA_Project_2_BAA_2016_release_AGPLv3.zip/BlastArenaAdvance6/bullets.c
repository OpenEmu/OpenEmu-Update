//======================================================================
//	bullets, 24x8@4, tiles. (mode 0,1,2; obj)
//	(Creation date: 2005-03-17, 11:15:37)
//
//	Exported by Cearn's Usenti v1.6.1
//	(comments, kudos, flames to "daytshen@hotmail.com")
//======================================================================

#include "bullets.h"

const int bulletsWidth= 24;
const int bulletsHeight= 8;
const int bulletsLen= 96;

const unsigned int bulletsData[24]=
{
	0x00000000, 0x000adda0, 0x000dffd0, 0x00bdffd0, 0x0abbdda0, 0x0abbb000, 0x00aa0000, 0x00000000, 
	0x00adda00, 0x00dffd00, 0x00dffd00, 0x00bddb00, 0x00bbbb00, 0x00abba00, 0x00abba00, 0x000aa000, 
	0x00000000, 0x00000000, 0x0aabbdda, 0xabbbdffd, 0xabbbdffd, 0x0aabbdda, 0x00000000, 0x00000000, 
};

