//
// gameovertiles declarations
//

#ifndef __GAMEOVERTILES__
#define __GAMEOVERTILES__

extern const int gameovertilesWidth;
extern const int gameovertilesHeight;
extern const int gameovertilesLen;
extern const unsigned int gameovertilesData[];
extern const int gameovertilesPalLen;
extern const unsigned int gameovertilesPal[];

#endif // __GAMEOVERTILES__

