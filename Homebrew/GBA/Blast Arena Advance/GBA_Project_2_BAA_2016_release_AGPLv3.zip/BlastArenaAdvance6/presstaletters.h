//
// presstaletters declarations
//

#ifndef __PRESSTALETTERS__
#define __PRESSTALETTERS__

extern const int presstalettersWidth;
extern const int presstalettersHeight;
extern const int presstalettersLen;
extern const unsigned int presstalettersData[];
extern const int presstalettersPalLen;
extern const unsigned int presstalettersPal[];

#endif // __PRESSTALETTERS__

