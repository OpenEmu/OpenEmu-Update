//
// collect declarations
//

#ifndef __COLLECT__
#define __COLLECT__

extern const int collectWidth;
extern const int collectHeight;
extern const int collectLen;
extern const unsigned int collectData[];

#endif // __COLLECT__

