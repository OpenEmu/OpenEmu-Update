//
// lcdskybackdrop declarations
//

#ifndef __LCDSKYBACKDROP__
#define __LCDSKYBACKDROP__

extern const int lcdskybackdropWidth;
extern const int lcdskybackdropHeight;
extern const int lcdskybackdropLen;
extern const unsigned int lcdskybackdropData[];
extern const int lcdskybackdropPalLen;
extern const unsigned int lcdskybackdropPal[];

#endif // __LCDSKYBACKDROP__

