//
// palls declarations
//

#ifndef __PALLS__
#define __PALLS__

extern const unsigned int pallsPal[];

#endif // __PALLS__

