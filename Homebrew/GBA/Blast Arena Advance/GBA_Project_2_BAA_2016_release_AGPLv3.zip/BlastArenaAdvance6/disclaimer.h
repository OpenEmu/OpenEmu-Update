//
// disclaimer declarations
//

#ifndef __DISCLAIMER__
#define __DISCLAIMER__

extern const int disclaimerWidth;
extern const int disclaimerHeight;
extern const int disclaimerLen;
extern const unsigned int disclaimerData[];
extern const int disclaimerPalLen;
extern const unsigned int disclaimerPal[];

#endif // __DISCLAIMER__

