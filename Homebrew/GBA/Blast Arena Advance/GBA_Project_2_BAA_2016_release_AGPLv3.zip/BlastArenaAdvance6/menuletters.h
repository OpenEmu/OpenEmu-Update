//
// menuletters declarations
//

#ifndef __MENULETTERS__
#define __MENULETTERS__

extern const int menulettersWidth;
extern const int menulettersHeight;
extern const int menulettersLen;
extern const unsigned int menulettersData[];
extern const int menulettersPalLen;
extern const unsigned int menulettersPal[];

#endif // __MENULETTERS__

