//
// mattlogo declarations
//

#ifndef __MATTLOGO__
#define __MATTLOGO__

extern const int mattlogoWidth;
extern const int mattlogoHeight;
extern const int mattlogoLen;
extern const unsigned int mattlogoData[];
extern const int mattlogoPalLen;
extern const unsigned int mattlogoPal[];

#endif // __MATTLOGO__

