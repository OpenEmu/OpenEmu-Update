//
// sparkle2 declarations
//

#ifndef __SPARKLE2__
#define __SPARKLE2__

extern const int sparkle2Width;
extern const int sparkle2Height;
extern const int sparkle2Len;
extern const unsigned int sparkle2Data[];

#endif // __SPARKLE2__

