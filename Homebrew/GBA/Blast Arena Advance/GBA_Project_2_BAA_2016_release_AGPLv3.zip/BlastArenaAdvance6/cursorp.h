//
// cursorp declarations
//

#ifndef __CURSORP__
#define __CURSORP__

extern const int cursorpWidth;
extern const int cursorpHeight;
extern const int cursorpLen;
extern const unsigned int cursorpData[];
extern const int cursorpPalLen;
extern const unsigned int cursorpPal[];

#endif // __CURSORP__

