//
// spritelight declarations
//

#ifndef __SPRITELIGHT__
#define __SPRITELIGHT__

extern const int spritelightWidth;
extern const int spritelightHeight;
extern const int spritelightLen;
extern const unsigned int spritelightData[];
extern const int spritelightPalLen;
extern const unsigned int spritelightPal[];

#endif // __SPRITELIGHT__

