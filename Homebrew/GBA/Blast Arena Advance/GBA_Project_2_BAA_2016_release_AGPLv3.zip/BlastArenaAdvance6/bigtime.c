//======================================================================
//	bigtime, 16x16@4, tiles. (mode 0,1,2; obj)
//	(Creation date: 2005-03-29, 17:51:52)
//
//	Exported by Cearn's Usenti v1.6.1
//	(comments, kudos, flames to "daytshen@hotmail.com")
//======================================================================

#include "bigtime.h"

const int bigtimeWidth= 16;
const int bigtimeHeight= 16;
const int bigtimeLen= 128;

const unsigned int bigtimeData[32]=
{
	0x44488000, 0x5a822300, 0xa2a83230, 0xa2a05328, 0xa2a00828, 0x2a000584, 0x2a000054, 0x2a000054, 
	0x00000094, 0x00009955, 0x00095000, 0x00900000, 0x05900000, 0x0900000a, 0x5400000a, 0x540000aa, 
	0xa0000054, 0x00000059, 0x00000090, 0x00000590, 0x00000900, 0x00099000, 0x44950000, 0x55000000, 
	0x5400aa22, 0x548a22aa, 0x5828aa00, 0x08230000, 0x05323800, 0x00532280, 0x00058844, 0x00000555, 
};

