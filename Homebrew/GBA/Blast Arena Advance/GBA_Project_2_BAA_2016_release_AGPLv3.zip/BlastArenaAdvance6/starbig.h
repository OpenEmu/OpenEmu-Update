//
// starbig declarations
//

#ifndef __STARBIG__
#define __STARBIG__

extern const int starbigWidth;
extern const int starbigHeight;
extern const int starbigLen;
extern const unsigned int starbigData[];

#endif // __STARBIG__

