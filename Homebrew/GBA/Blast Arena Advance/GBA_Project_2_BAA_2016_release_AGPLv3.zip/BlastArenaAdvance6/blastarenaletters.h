//
// blastarenaletters declarations
//

#ifndef __BLASTARENALETTERS__
#define __BLASTARENALETTERS__

extern const int blastarenalettersWidth;
extern const int blastarenalettersHeight;
extern const int blastarenalettersLen;
extern const unsigned int blastarenalettersData[];
extern const int blastarenalettersPalLen;
extern const unsigned int blastarenalettersPal[];

#endif // __BLASTARENALETTERS__

