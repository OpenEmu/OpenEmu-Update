//
// bigtime declarations
//

#ifndef __BIGTIME__
#define __BIGTIME__

extern const int bigtimeWidth;
extern const int bigtimeHeight;
extern const int bigtimeLen;
extern const unsigned int bigtimeData[];

#endif // __BIGTIME__

