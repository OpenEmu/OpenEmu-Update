//======================================================================
//	collect, 8x8@4, tiles. (mode 0,1,2; obj)
//	(Creation date: 2005-03-20, 02:50:31)
//
//	Exported by Cearn's Usenti v1.6.1
//	(comments, kudos, flames to "daytshen@hotmail.com")
//======================================================================

#include "collect.h"

const int collectWidth= 8;
const int collectHeight= 8;
const int collectLen= 32;

const unsigned int collectData[8]=
{
	0x24444442, 0x43000034, 0x40000004, 0x40000004, 0x40000004, 0x40000004, 0x43000034, 0x24444442, 
};

