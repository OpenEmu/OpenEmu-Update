//
// texttiles declarations
//

#ifndef __TEXTTILES__
#define __TEXTTILES__

extern const int texttilesWidth;
extern const int texttilesHeight;
extern const int texttilesLen;
extern const unsigned int texttilesData[];

#endif // __TEXTTILES__

