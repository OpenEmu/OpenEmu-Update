#ifndef __MESSAGES__
#define __MESSAGES__

extern const char copyright2[];
extern const char copyright[];

#endif // __MESSAGES__

