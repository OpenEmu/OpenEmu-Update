//
// blastbonus declarations
//

#ifndef __BLASTBONUS__
#define __BLASTBONUS__

extern const int blastbonusWidth;
extern const int blastbonusHeight;
extern const int blastbonusLen;
extern const unsigned int blastbonusData[];

#endif // __BLASTBONUS__

