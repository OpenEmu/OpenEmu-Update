//
// BGbackg declarations
//

#ifndef __BGBACKG__
#define __BGBACKG__

extern const int BGbackgWidth;
extern const int BGbackgHeight;
extern const int BGbackgLen;
extern const unsigned int BGbackgData[];
extern const int BGbackgPalLen;
extern const unsigned int BGbackgPal[];

#endif // __BGBACKG__

