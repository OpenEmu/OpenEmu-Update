//
// appearbox declarations
//

#ifndef __APPEARBOX__
#define __APPEARBOX__

extern const int appearboxWidth;
extern const int appearboxHeight;
extern const int appearboxLen;
extern const unsigned int appearboxData[];

#endif // __APPEARBOX__

