//
// snakeblocks declarations
//

#ifndef __SNAKEBLOCKS__
#define __SNAKEBLOCKS__

extern const int snakeblocksWidth;
extern const int snakeblocksHeight;
extern const int snakeblocksLen;
extern const unsigned int snakeblocksData[];
extern const int snakeblocksPalLen;
extern const unsigned int snakeblocksPal[];

#endif // __SNAKEBLOCKS__

