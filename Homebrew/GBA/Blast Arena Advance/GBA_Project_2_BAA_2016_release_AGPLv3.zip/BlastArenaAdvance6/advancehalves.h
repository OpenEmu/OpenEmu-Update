//
// advancehalves declarations
//

#ifndef __ADVANCEHALVES__
#define __ADVANCEHALVES__

extern const int advancehalvesWidth;
extern const int advancehalvesHeight;
extern const int advancehalvesLen;
extern const unsigned int advancehalvesData[];
extern const int advancehalvesPalLen;
extern const unsigned int advancehalvesPal[];

#endif // __ADVANCEHALVES__

