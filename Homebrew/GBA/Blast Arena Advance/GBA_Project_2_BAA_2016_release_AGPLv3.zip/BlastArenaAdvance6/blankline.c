//======================================================================
//	blankline, 32x8@4, tiles. (mode 0,1,2; obj)
//	(Creation date: 2005-05-07, 00:19:37)
//
//	Exported by Cearn's Usenti v1.6.1
//	(comments, kudos, flames to "daytshen@hotmail.com")
//======================================================================

#include "blankline.h"

const int blanklineWidth= 32;
const int blanklineHeight= 8;
const int blanklineLen= 128;

const unsigned int blanklineData[32]=
{
	0x11111111, 0x11111111, 0x11111111, 0x11111111, 0x11111111, 0x00000000, 0x00000000, 0x00000000, 
	0x11111111, 0x11111111, 0x11111111, 0x11111111, 0x11111111, 0x00000000, 0x00000000, 0x00000000, 
	0x11111111, 0x11111111, 0x11111111, 0x11111111, 0x11111111, 0x00000000, 0x00000000, 0x00000000, 
	0x11111111, 0x11111111, 0x11111111, 0x11111111, 0x11111111, 0x00000000, 0x00000000, 0x00000000, 
};

