//
// largenum declarations
//

#ifndef __LARGENUM__
#define __LARGENUM__

extern const int largenumWidth;
extern const int largenumHeight;
extern const int largenumLen;
extern const unsigned int largenumData[];

#endif // __LARGENUM__

