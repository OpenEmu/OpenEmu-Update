//======================================================================
//	hiarrow, 16x8@4, tiles. (mode 0,1,2; obj)
//	(Creation date: 2005-05-15, 20:23:36)
//
//	Exported by Cearn's Usenti v1.6.1
//	(comments, kudos, flames to "daytshen@hotmail.com")
//======================================================================

#include "hiarrow.h"

const int hiarrowWidth= 16;
const int hiarrowHeight= 8;
const int hiarrowLen= 64;

const unsigned int hiarrowData[16]=
{
	0x02620000, 0x06862000, 0x02686200, 0x00268620, 0x00026860, 0x66666786, 0x88888887, 0x55555550, 
	0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00666666, 0x05888888, 0x00555555, 
};

