//
// blinkbar declarations
//

#ifndef __BLINKBAR__
#define __BLINKBAR__

extern const int blinkbarWidth;
extern const int blinkbarHeight;
extern const int blinkbarLen;
extern const unsigned int blinkbarData[];

#endif // __BLINKBAR__

