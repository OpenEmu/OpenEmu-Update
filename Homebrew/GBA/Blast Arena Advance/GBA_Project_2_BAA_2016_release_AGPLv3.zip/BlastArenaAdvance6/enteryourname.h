//
// enteryourname declarations
//

#ifndef __ENTERYOURNAME__
#define __ENTERYOURNAME__

extern const int enteryournameWidth;
extern const int enteryournameHeight;
extern const int enteryournameLen;
extern const unsigned int enteryournameData[];
extern const int enteryournamePalLen;
extern const unsigned int enteryournamePal[];

#endif // __ENTERYOURNAME__

