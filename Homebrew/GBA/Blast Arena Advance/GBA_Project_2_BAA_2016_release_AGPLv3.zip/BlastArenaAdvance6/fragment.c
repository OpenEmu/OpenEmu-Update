//======================================================================
//	fragment, 8x8@4, tiles. (mode 0,1,2; obj)
//	(Creation date: 2005-03-17, 12:08:46)
//
//	Exported by Cearn's Usenti v1.6.1
//	(comments, kudos, flames to "daytshen@hotmail.com")
//======================================================================

#include "fragment.h"

const int fragmentWidth= 8;
const int fragmentHeight= 8;
const int fragmentLen= 32;

const unsigned int fragmentData[8]=
{
	0x00000000, 0x00000000, 0x00255200, 0x00577500, 0x00577500, 0x00255200, 0x00000000, 0x00000000, 
};

