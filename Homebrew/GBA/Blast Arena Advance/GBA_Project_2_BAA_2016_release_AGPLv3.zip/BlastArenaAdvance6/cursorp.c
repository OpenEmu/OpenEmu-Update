//======================================================================
//	cursorp, 8x8@4, tiles. (mode 0,1,2; obj)
//	(Creation date: 2005-03-16, 23:00:35)
//
//	Exported by Cearn's Usenti v1.6.1
//	(comments, kudos, flames to "daytshen@hotmail.com")
//======================================================================

#include "cursorp.h"

const int cursorpWidth= 8;
const int cursorpHeight= 8;
const int cursorpLen= 32;

const unsigned int cursorpData[8]=
{
	0x00122221, 0x00122221, 0x00122221, 0x00122221, 0x00122221, 0x00000000, 0x00000000, 0x00000000, 
};

const int cursorpPalLen= 6;
const unsigned int cursorpPal[2]=
{
	0x67390000, 0x00007fff, 
};

