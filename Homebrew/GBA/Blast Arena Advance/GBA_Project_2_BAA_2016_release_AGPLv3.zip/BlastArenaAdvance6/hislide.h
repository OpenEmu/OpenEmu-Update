//
// whiteline declarations
//

#ifndef __HISLIDE__
#define __HISLIDE__

extern const unsigned char hislideData[30];

#endif // __HISLIDE__

