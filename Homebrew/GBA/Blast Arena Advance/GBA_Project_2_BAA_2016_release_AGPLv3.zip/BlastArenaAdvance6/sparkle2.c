//======================================================================
//	sparkle2, 8x8@4, tiles. (mode 0,1,2; obj)
//	(Creation date: 2005-03-20, 22:29:20)
//
//	Exported by Cearn's Usenti v1.6.1
//	(comments, kudos, flames to "daytshen@hotmail.com")
//======================================================================

#include "sparkle2.h"

const int sparkle2Width= 8;
const int sparkle2Height= 8;
const int sparkle2Len= 32;

const unsigned int sparkle2Data[8]=
{
	0x00005000, 0x00003000, 0x00053500, 0x05334335, 0x00053500, 0x00003000, 0x00005000, 0x00000000, 
};

