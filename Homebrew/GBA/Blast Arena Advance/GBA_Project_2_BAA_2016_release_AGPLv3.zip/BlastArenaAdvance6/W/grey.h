//
// grey declarations
//

#ifndef __GREY__
#define __GREY__

extern const int greyWidth;
extern const int greyHeight;
extern const int greyLen;
extern const unsigned int greyData[];
extern const int greyPalLen;
extern const unsigned int greyPal[];

#endif // __GREY__

