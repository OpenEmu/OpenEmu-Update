//
// gameovertiles16 declarations
//

#ifndef __GAMEOVERTILES16__
#define __GAMEOVERTILES16__

extern const int gameovertiles16Width;
extern const int gameovertiles16Height;
extern const int gameovertiles16Len;
extern const unsigned int gameovertiles16Data[];

#endif // __GAMEOVERTILES16__

