//
// swoosh declarations
//

#ifndef __SWOOSH__
#define __SWOOSH__

extern const int swooshWidth;
extern const int swooshHeight;
extern const int swooshLen;
extern const unsigned int swooshData[];
extern const int swooshPalLen;
extern const unsigned int swooshPal[];

#endif // __SWOOSH__

