//
// bullets declarations
//

#ifndef __BULLETS__
#define __BULLETS__

extern const int bulletsWidth;
extern const int bulletsHeight;
extern const int bulletsLen;
extern const unsigned int bulletsData[];

#endif // __BULLETS__

