//
// warningbox declarations
//

#ifndef __WARNINGBOX__
#define __WARNINGBOX__

extern const int warningboxWidth;
extern const int warningboxHeight;
extern const int warningboxLen;
extern const unsigned int warningboxData[];
extern const int warningboxPalLen;
extern const unsigned int warningboxPal[];

#endif // __WARNINGBOX__

