//
// goldstarpall declarations
//

#ifndef __GOLDSTARPALL__
#define __GOLDSTARPALL__

extern const int goldstarpallWidth;
extern const int goldstarpallHeight;
extern const int goldstarpallLen;
extern const unsigned int goldstarpallData[];
extern const int goldstarpallPalLen;
extern const unsigned int goldstarpallPal[];

#endif // __GOLDSTARPALL__

