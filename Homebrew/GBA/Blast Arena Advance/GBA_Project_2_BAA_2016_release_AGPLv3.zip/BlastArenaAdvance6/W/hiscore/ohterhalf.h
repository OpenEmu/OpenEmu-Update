//
// ohterhalf declarations
//

#ifndef __OHTERHALF__
#define __OHTERHALF__

extern const int ohterhalfWidth;
extern const int ohterhalfHeight;
extern const int ohterhalfLen;
extern const unsigned int ohterhalfData[];

#endif // __OHTERHALF__

