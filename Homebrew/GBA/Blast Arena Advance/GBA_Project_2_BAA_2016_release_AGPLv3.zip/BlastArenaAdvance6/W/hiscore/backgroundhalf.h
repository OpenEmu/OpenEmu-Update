//
// backgroundhalf declarations
//

#ifndef __BACKGROUNDHALF__
#define __BACKGROUNDHALF__

extern const int backgroundhalfWidth;
extern const int backgroundhalfHeight;
extern const int backgroundhalfLen;
extern const unsigned int backgroundhalfData[];
extern const int backgroundhalfPalLen;
extern const unsigned int backgroundhalfPal[];

#endif // __BACKGROUNDHALF__

