//
// hiscoretiles declarations
//

#ifndef __HISCORETILES__
#define __HISCORETILES__

extern const int hiscoretilesWidth;
extern const int hiscoretilesHeight;
extern const int hiscoretilesLen;
extern const unsigned int hiscoretilesData[];
extern const int hiscoretilesPalLen;
extern const unsigned int hiscoretilesPal[];

#endif // __HISCORETILES__

