//
// BGspritespart2 declarations
//

#ifndef __BGSPRITESPART2__
#define __BGSPRITESPART2__

extern const int BGspritespart2Width;
extern const int BGspritespart2Height;
extern const int BGspritespart2Len;
extern const unsigned int BGspritespart2Data[];

#endif // __BGSPRITESPART2__

