//
// BGspritespart3 declarations
//

#ifndef __BGSPRITESPART3__
#define __BGSPRITESPART3__

extern const int BGspritespart3Width;
extern const int BGspritespart3Height;
extern const int BGspritespart3Len;
extern const unsigned int BGspritespart3Data[];

#endif // __BGSPRITESPART3__

