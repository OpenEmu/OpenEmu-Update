//
// gbaxsplash declarations
//

#ifndef __GBAXSPLASH__
#define __GBAXSPLASH__

extern const int gbaxsplashWidth;
extern const int gbaxsplashHeight;
extern const int gbaxsplashLen;
extern const unsigned int gbaxsplashData[];
extern const int gbaxsplashPalLen;
extern const unsigned int gbaxsplashPal[];

#endif // __GBAXSPLASH__

