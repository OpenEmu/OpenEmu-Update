//======================================================================
//	whiteline, 8x8@4, tiles. (mode 0,1,2; obj)
//	(Creation date: 2005-05-06, 23:41:14)
//
//	Exported by Cearn's Usenti v1.6.1
//	(comments, kudos, flames to "daytshen@hotmail.com")
//======================================================================

#include "whiteline.h"

const int whitelineWidth= 8;
const int whitelineHeight= 8;
const int whitelineLen= 32;

const unsigned int whitelineData[8]=
{
	0x00000001, 0x00000001, 0x00000001, 0x00000001, 0x00000001, 0x00000001, 0x00000001, 0x00000001, 
};

