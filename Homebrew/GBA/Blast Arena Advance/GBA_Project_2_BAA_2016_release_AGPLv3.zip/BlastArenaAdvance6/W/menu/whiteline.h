//
// whiteline declarations
//

#ifndef __WHITELINE__
#define __WHITELINE__

extern const int whitelineWidth;
extern const int whitelineHeight;
extern const int whitelineLen;
extern const unsigned int whitelineData[];

#endif // __WHITELINE__

