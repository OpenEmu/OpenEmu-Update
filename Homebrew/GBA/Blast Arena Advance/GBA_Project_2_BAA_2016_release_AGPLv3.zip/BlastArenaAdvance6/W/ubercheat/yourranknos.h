//
// yourranknos declarations
//

#ifndef __YOURRANKNOS__
#define __YOURRANKNOS__

extern const int yourranknosWidth;
extern const int yourranknosHeight;
extern const int yourranknosLen;
extern const unsigned int yourranknosData[];

#endif // __YOURRANKNOS__

