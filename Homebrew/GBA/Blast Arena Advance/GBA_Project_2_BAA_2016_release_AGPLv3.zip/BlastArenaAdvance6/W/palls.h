//
// palls declarations
//

#ifndef __PALLS__
#define __PALLS__

extern const int pallsWidth;
extern const int pallsHeight;
extern const int pallsLen;
extern const unsigned int pallsData[];
extern const int pallsPalLen;
extern const unsigned int pallsPal[];

#endif // __PALLS__

