//
// star declarations
//

#ifndef __STAR__
#define __STAR__

extern const int starWidth;
extern const int starHeight;
extern const int starLen;
extern const unsigned int starData[];

#endif // __STAR__

