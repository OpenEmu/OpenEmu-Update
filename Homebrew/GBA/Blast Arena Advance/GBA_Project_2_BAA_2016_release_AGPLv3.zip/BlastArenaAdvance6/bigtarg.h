//
// bigtarg declarations
//

#ifndef __BIGTARG__
#define __BIGTARG__

extern const int bigtargWidth;
extern const int bigtargHeight;
extern const int bigtargLen;
extern const unsigned int bigtargData[];

#endif // __BIGTARG__

