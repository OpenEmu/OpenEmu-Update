//
// speedyglowbox declarations
//

#ifndef __SPEEDYGLOWBOX__
#define __SPEEDYGLOWBOX__

extern const int speedyglowboxWidth;
extern const int speedyglowboxHeight;
extern const int speedyglowboxLen;
extern const unsigned int speedyglowboxData[];
extern const int speedyglowboxPalLen;
extern const unsigned int speedyglowboxPal[];

#endif // __SPEEDYGLOWBOX__

