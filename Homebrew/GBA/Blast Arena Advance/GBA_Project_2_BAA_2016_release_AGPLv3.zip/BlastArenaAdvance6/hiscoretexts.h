//
// hiscoretexts declarations
//

#ifndef __HISCORETEXTS__
#define __HISCORETEXTS__

extern const int hiscoretextsWidth;
extern const int hiscoretextsHeight;
extern const int hiscoretextsLen;
extern const unsigned int hiscoretextsData[];

#endif // __HISCORETEXTS__

