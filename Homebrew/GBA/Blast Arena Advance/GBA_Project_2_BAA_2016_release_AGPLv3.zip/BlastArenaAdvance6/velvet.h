//
// velvet declarations
//

#ifndef __VELVET__
#define __VELVET__

extern const int velvetWidth;
extern const int velvetHeight;
extern const int velvetLen;
extern const unsigned int velvetData[];
extern const int velvetPalLen;
extern const unsigned int velvetPal[];

#endif // __VELVET__

