//
// detected declarations
//

#ifndef __DETECTED__
#define __DETECTED__

extern const int detectedWidth;
extern const int detectedHeight;
extern const int detectedLen;
extern const unsigned int detectedData[];

#endif // __DETECTED__

