//
// hiarrow declarations
//

#ifndef __HIARROW__
#define __HIARROW__

extern const int hiarrowWidth;
extern const int hiarrowHeight;
extern const int hiarrowLen;
extern const unsigned int hiarrowData[];

#endif // __HIARROW__

