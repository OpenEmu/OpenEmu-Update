//
// swooshd declarations
//

#ifndef __SWOOSHD__
#define __SWOOSHD__

extern const int swooshdWidth;
extern const int swooshdHeight;
extern const int swooshdLen;
extern const unsigned int swooshdData[];
extern const int swooshdPalLen;
extern const unsigned int swooshdPal[];

#endif // __SWOOSHD__

