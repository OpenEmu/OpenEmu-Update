//======================================================================
//	grey, 32x32@4, tiles. (mode 0,1,2; obj)
//	(Creation date: 2005-03-17, 23:53:01)
//
//	Exported by Cearn's Usenti v1.6.1
//	(comments, kudos, flames to "daytshen@hotmail.com")
//======================================================================

#include "grey.h"

const unsigned int greyPal[4]=
{
	0x04210000, 0x14a50c63, 0x210818c6, 0x318c294a, 
};

