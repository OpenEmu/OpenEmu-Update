//
// sparkle declarations
//

#ifndef __SPARKLE__
#define __SPARKLE__

extern const int sparkleWidth;
extern const int sparkleHeight;
extern const int sparkleLen;
extern const unsigned int sparkleData[];

#endif // __SPARKLE__

