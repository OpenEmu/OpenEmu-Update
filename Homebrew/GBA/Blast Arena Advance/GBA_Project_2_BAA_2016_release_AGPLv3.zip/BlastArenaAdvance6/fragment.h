//
// fragment declarations
//

#ifndef __FRAGMENT__
#define __FRAGMENT__

extern const int fragmentWidth;
extern const int fragmentHeight;
extern const int fragmentLen;
extern const unsigned int fragmentData[];

#endif // __FRAGMENT__

