//
// BGsprites declarations
//

#ifndef __BGSPRITES__
#define __BGSPRITES__

extern const int BGspritesWidth;
extern const int BGspritesHeight;
extern const int BGspritesLen;
extern const unsigned int BGspritesData[];
extern const int BGspritesPalLen;
extern const unsigned int BGspritesPal[];

#endif // __BGSPRITES__

