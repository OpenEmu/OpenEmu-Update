//
// retrytext declarations
//

#ifndef __RETRYTEXT__
#define __RETRYTEXT__

extern const int retrytextWidth;
extern const int retrytextHeight;
extern const int retrytextLen;
extern const unsigned int retrytextData[];
extern const int retrytextPalLen;
extern const unsigned int retrytextPal[];

#endif // __RETRYTEXT__

