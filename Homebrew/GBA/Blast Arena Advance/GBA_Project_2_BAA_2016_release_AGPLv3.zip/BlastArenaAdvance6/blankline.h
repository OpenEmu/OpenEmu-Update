//
// blankline declarations
//

#ifndef __BLANKLINE__
#define __BLANKLINE__

extern const int blanklineWidth;
extern const int blanklineHeight;
extern const int blanklineLen;
extern const unsigned int blanklineData[];

#endif // __BLANKLINE__

