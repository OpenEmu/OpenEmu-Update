//======================================================================
//	bigtarg, 16x16@4, tiles. (mode 0,1,2; obj)
//	(Creation date: 2005-03-24, 23:11:44)
//
//	Exported by Cearn's Usenti v1.6.1
//	(comments, kudos, flames to "daytshen@hotmail.com")
//======================================================================

#include "bigtarg.h"

const int bigtargWidth= 16;
const int bigtargHeight= 16;
const int bigtargLen= 128;

const unsigned int bigtargData[32]=
{
	0x00000500, 0xb5a89480, 0x44444245, 0xb5a89490, 0x00008480, 0x0000a4a0, 0x00005450, 0x0000b4b0, 
	0x00500000, 0x08498a5b, 0x54244444, 0x09498a5b, 0x08480000, 0x0a4a0000, 0x05450000, 0x0b4b0000, 
	0x0000b4b0, 0x00005450, 0x0000a4a0, 0x00008480, 0xb5a89490, 0x44444245, 0xb5a89480, 0x00000500, 
	0x0b4b0000, 0x05450000, 0x0a4a0000, 0x08480000, 0x09498a5b, 0x54244444, 0x08498a5b, 0x00500000, 
};

