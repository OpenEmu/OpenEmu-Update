//
// cheatarrows declarations
//

#ifndef __CHEATARROWS__
#define __CHEATARROWS__

extern const int cheatarrowsWidth;
extern const int cheatarrowsHeight;
extern const int cheatarrowsLen;
extern const unsigned int cheatarrowsData[];

#endif // __CHEATARROWS__

