//
// blastarenatitlescreen declarations
//

#ifndef __BLASTARENATITLESCREEN__
#define __BLASTARENATITLESCREEN__

extern const int blastarenatitlescreenWidth;
extern const int blastarenatitlescreenHeight;
extern const int blastarenatitlescreenLen;
extern const unsigned int blastarenatitlescreenData[];
extern const int blastarenatitlescreenPalLen;
extern const unsigned int blastarenatitlescreenPal[];

#endif // __BLASTARENATITLESCREEN__

