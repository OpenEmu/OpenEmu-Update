//======================================================================
//	blinkbar, 16x8@4, tiles. (mode 0,1,2; obj)
//	(Creation date: 2005-05-19, 22:14:05)
//
//	Exported by Cearn's Usenti v1.6.1
//	(comments, kudos, flames to "daytshen@hotmail.com")
//======================================================================

#include "blinkbar.h"

const int blinkbarWidth= 16;
const int blinkbarHeight= 8;
const int blinkbarLen= 64;

const unsigned int blinkbarData[16]=
{
	0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x88888882, 0x55544320, 
	0x00145410, 0x01888881, 0x00145784, 0x00000585, 0x00000484, 0x00000181, 0x00000010, 0x00000000, 
};

