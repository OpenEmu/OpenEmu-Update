// =====================================================================
//
//	Exported by Cearn's excellut v0.9
//	(comments, kudos, flames to daytshen@hotmail.com)
//
// =====================================================================

#ifndef SINLUT_H
#define SINLUT_H

// === LUT SIZES ===
#define SIN_SIZE 512


// === LUT DECLARATIONS ===
extern const signed short _sinLUT[];


#endif	// SINLUT_H
