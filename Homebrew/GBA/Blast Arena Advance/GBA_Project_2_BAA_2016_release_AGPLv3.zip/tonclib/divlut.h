// =====================================================================
//
//	Exported by Cearn's excellut v0.9
//	(comments, kudos, flames to daytshen@hotmail.com)
//
// =====================================================================

#ifndef DIVLUT_H
#define DIVLUT_H

// === LUT SIZES ===
#define DIV_SIZE 160

// === LUT DECLARATIONS ===
extern const signed int DIV[];


#endif	// DIVLUT_H
