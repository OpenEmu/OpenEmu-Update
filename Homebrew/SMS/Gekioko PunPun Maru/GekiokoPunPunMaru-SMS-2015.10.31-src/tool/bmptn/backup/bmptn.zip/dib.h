#define BITMAPFILEHEADER_SIZE	14

struct BITMAPFILEHEADER {
	unsigned short bfType;
	unsigned int   bfSize;
	unsigned short bfReserved1;
	unsigned short bfReserved2;
	unsigned int   bfOffBits;
} __attribute__ ((packed)) /* for gcc */;

#define BITMAPINFOHEADER_SIZE	40
struct BITMAPINFOHEADER {
	unsigned int   biSize;
	int            biWidth;
	int            biHeight;
	unsigned short biPlanes;
	unsigned short biBitCount;
	unsigned int   biCompression;
	unsigned int   biSizeImage;
	int            biXPixPerMeter;
	int            biYPixPerMeter;
	unsigned int   biClrUsed;
	unsigned int   biClrImporant;
} __attribute__ ((packed)) /* for gcc */;

