#include <stdio.h>
#include <stdlib.h>
#include "dib.h"
#include "bmptn.h"

char *bmpPath;	/* path for bmp file */
char *ptnPath;	/* path for pattern file */
int bmpWidth;	/* pixel width */
int bmpHeight;	/* pixel height */
int ptnHeight[256];	/* pixel height per line */
unsigned char *bmp;	/* bmp buffer, pixel array only */
unsigned char *ptn;	/* pattern buffer */
int heightLimit;	/* pixel height limit */

int main(int argc, char *argv[]){

	if(argc < 3){
		fprintf(stderr, "Need more arguments.\n");
		exit(EXIT_FAILURE);
	}
	bmpPath = argv[1];
	ptnPath = argv[2];

	if(readBmp()) exit(EXIT_FAILURE);
	if(makePtnHeight(argc, argv)) exit(EXIT_FAILURE);
	if(transform()) exit(EXIT_FAILURE);
	if(writePtn()) exit(EXIT_FAILURE);

}
/* make ptnHeight[] from argv */
int makePtnHeight(int argc, char *argv[]){
	int count;
	int height;
	int h;

	h = 8;
	count = 0;
	for(height = 0; height < bmpHeight; height += h){
		if(count < (argc - 3)){
			if(sscanf(argv[count + 3], "%d", &h) != 1){
				fprintf(stderr, "A height argument is not integer.\n");
				return 1;
			}
		}
		if(h < 0){
			fprintf(stderr, "A height argument is minus.\n");
			return 1;
		}
		ptnHeight[count] = h;
		count++;
	}
	return 0;
}
/* read bmp file to "bmp" buffer */
int readBmp(){
	FILE *fp;
	struct BITMAPFILEHEADER bmpFileHeader;
	struct BITMAPINFOHEADER bmpInfoHeader;
	int dataOffset;
	int l;

	/* open */
	fp = fopen(bmpPath, "rb");
	if(fp == NULL){
		fprintf(stderr, "Cannot open BMP file: %s\n", bmpPath);
		return 1;
	}

	/* read header chunk */
	l = fread(&bmpFileHeader, 1, BITMAPFILEHEADER_SIZE, fp);
	if(l != BITMAPFILEHEADER_SIZE){
		fprintf(stderr, "Cannot read file header from BMP file: %s\n", bmpPath);
		fclose(fp);
		return 1;
	}
	l = fread(&bmpInfoHeader, 1, BITMAPINFOHEADER_SIZE, fp);
	if(l != BITMAPINFOHEADER_SIZE){
		fprintf(stderr, "Cannot read info header from BMP file: %s\n", bmpPath);
		fclose(fp);
		return 1;
	}
	dataOffset = bmpFileHeader.bfOffBits;
	bmpWidth = bmpInfoHeader.biWidth;
	bmpHeight = bmpInfoHeader.biHeight;

	/* read data chunk */
	bmp = (char *)calloc(bmpWidth * bmpHeight, 1);
	if(bmp == NULL){
		exit(EXIT_FAILURE);
	}
	fseek(fp, dataOffset, SEEK_SET);
	l = fread(bmp, 1, bmpWidth * bmpHeight, fp);
	if(l != (bmpWidth * bmpHeight)){
		fprintf(stderr, "Cannot read from BMP file: %s\n", bmpPath);
		fclose(fp);
		return 1;
	}
	fclose(fp);

	/* get pattern buffer */
	ptn = (char *)calloc(bmpWidth * bmpHeight, 1);
	if(ptn == NULL){
		exit(EXIT_FAILURE);
	}
	return 0;
}
/* transform bmp to pattern */
int transform(){
	int x;	/* x position for bmp */
	int y;	/* y position for bmp */
	int px;	/* x position for pattern */
	int py;	/* y position for pattern */
	int i;	/* line position for bmp */
	unsigned int d1;	/* pixel data 1st (odd nibble) */
	unsigned int d2;	/* pixel data 2nd (even nibble) */
	unsigned char *p;

	p = ptn;
	y = 0;
	for(i = 0; ptnHeight[i] != 0; i++){
		for(x = 0; x < bmpWidth; x += 8){
			for(py = 0; py < ptnHeight[i]; py++){
				for(px = 0; px < 8; px += 2){
					/* odd */
					d1 = getPixel(x + px + 0, y + py);
					if(d1 > 255) return 0;

					/* even */
					d2 = getPixel(x + px + 1, y + py);
					if(d2 > 255) return 0;

					/* nibbe + nibble = byte */
					*p++ = (d1 << 4) + d2;
				}
			}
		}
		y += ptnHeight[i];
	}
	return 0;
}
/* get a pixel form "bmp" buffer with range out check */
unsigned int getPixel(int x, int y){
	int xy;
	unsigned char *b;

	if((x > bmpWidth) || (y > bmpHeight)){
		fprintf(stderr, "Read error, bad args of getPixel function: x = %d, y = %d", x, y);
		return 256;
	}
	xy = x + (y * bmpWidth);
	b = bmp;
	b += xy;
	return (unsigned int)(*b & 0x0F);
}
/* create pattern file */
int writePtn(){
	FILE *fp;
	int l;

	fp = fopen(ptnPath, "wb");
	if(fp == NULL){
		fprintf(stderr, "Cannot create pattern file: %s\n", ptnPath);
		return 1;
	}
	l = fwrite(ptn, 1, (bmpWidth * bmpHeight / 2), fp);
	if(l != (bmpWidth * bmpHeight / 2)){
		fprintf(stderr, "Cannot write to pattern file: %s\n", ptnPath);
		fclose(fp);
		return 1;
	}
	fclose(fp);
	return 0;
}
